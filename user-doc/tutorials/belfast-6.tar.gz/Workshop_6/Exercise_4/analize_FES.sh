nfes=$(( $1 -1 ))
minA=$2
maxA=$3
minB=$4
maxB=$5
kbt=$6

for i in `seq 0 ${nfes}`
do

 A=`awk 'BEGIN{totA=0.0}{if($1!="#!" && $1>minA && $1<maxA)totA+=exp(-$2/kbt)}END{print -kbt*log(totA)}' minA=${minA} maxA=${maxA} kbt=${kbt} fes_${i}.dat`
 B=`awk 'BEGIN{totB=0.0}{if($1!="#!" && $1>minB && $1<maxB)totB+=exp(-$2/kbt)}END{print -kbt*log(totB)}' minB=${minB} maxB=${maxB} kbt=${kbt} fes_${i}.dat`

 Delta=`echo "${A} - ${B}" | bc -l`
 echo $i $Delta

done
